package stepdefs;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import ApplicationPages.Signinpage;
import WebConnector.webconnector;
import io.cucumber.core.api.Scenario;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SignInSteps extends webconnector{
	private Signinpage signInPage;
	private String scenDesc;

	public SignInSteps(){
		this.signInPage = new Signinpage();
	}

	@Before
	public void before(Scenario scenario) {
		//this.scenDesc = scenario.getName();
		setUpDriver();
	}

	@After
	public void after(Scenario scenario){
		closeDriver(scenario);
	}

//	@BeforeStep
//	public void beforeStep() throws InterruptedException {
//		Thread.sleep(2000);
//	}


	@Given("I am on Website")
	public void applicationIsLoaded() throws InvalidFormatException, IOException {
		this.signInPage.appIsLoaded();
	}

	@When("I enter username and password")
	public void LoginTest() throws Exception {
		this.signInPage.clickSignIn();
		this.signInPage.enterUsername();
		this.signInPage.enterPassword();
		this.signInPage.clickSignInButton();
		
//		driver.findElement(By.id("email")).sendKeys("SeleniumTesting@gmail.com");
//		driver.findElement(By.id("passwd")).sendKeys("Selenium123.");
//		driver.findElement(By.id("SubmitLogin")).click();
		
	}

	@Then("I am successfully logged in")
	public void validateLogin() throws Exception {
		this.signInPage.loggedIn();
		//Assert.assertTrue(driver.getCurrentUrl().contains("my-account"));
	}
//
//	@Given("I am logged in to application")
//	public void i_am_logged_in_to_application() {
//		Assert.assertTrue(driver.getCurrentUrl().contains("my-account"));
//	}
//
//	@When("I select the T-shirt")
//	public void i_select_the_t_shirt() {
//
//	}
//
//	@When("I order the T-shirt")
//	public void i_order_the_t_shirt() {
//		// Write code here that turns the phrase above into concrete actions
//		throw new io.cucumber.java.PendingException();
//	}
//
//	@Then("I can see ordered T-shirt in Order History")
//	public void i_can_see_ordered_t_shirt_in_order_history() {
//		// Write code here that turns the phrase above into concrete actions
//		throw new io.cucumber.java.PendingException();
//	}
//


}
